package com.appirio.mobile;

import android.view.Menu;

import com.salesforce.androidsdk.ui.LoginActivity;

public class AMLoginActivity extends LoginActivity {

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		return false;
	}

}
