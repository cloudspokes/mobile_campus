/** Automatically generated file. DO NOT MODIFY */
package com.appirio.aau;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}